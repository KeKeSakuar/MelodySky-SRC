/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.command;

import org.newdawn.slick.command.ControllerControl;

public class ControllerButtonControl
extends ControllerControl {
    public ControllerButtonControl(int controllerIndex, int button) {
        super(controllerIndex, 0, button);
    }
}

