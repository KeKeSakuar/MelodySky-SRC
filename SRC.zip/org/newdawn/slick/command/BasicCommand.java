/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.command;

import org.newdawn.slick.command.Command;

public class BasicCommand
implements Command {
    public static char[] var1;
    public static String var2;
    public static String var3;
    public static String var4;
    public static String var5;
    public static String var6;
    private String name;

    public BasicCommand(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public int hashCode() {
        return this.name.hashCode();
    }

    public boolean equals(Object other) {
        if (other instanceof BasicCommand) {
            return ((BasicCommand)other).name.equals(this.name);
        }
        return false;
    }

    public String toString() {
        return "[Command=" + this.name + "]";
    }
}

