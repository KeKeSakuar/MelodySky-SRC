/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.command;

public interface Command {
}

