/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick;

public class SlickException
extends Exception {
    public SlickException(String message) {
        super(message);
    }

    public SlickException(String message, Throwable e) {
        super(message, e);
    }
}

