/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.geom;

import org.newdawn.slick.geom.Vector2f;

public interface TexCoordGenerator {
    public Vector2f getCoordFor(float var1, float var2);
}

