/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.geom;

public interface GeomUtilListener {
    public void pointExcluded(float var1, float var2);

    public void pointIntersected(float var1, float var2);

    public void pointUsed(float var1, float var2);
}

