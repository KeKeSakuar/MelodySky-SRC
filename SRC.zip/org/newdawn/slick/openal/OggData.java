/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.openal;

import java.nio.ByteBuffer;

public class OggData {
    public ByteBuffer data;
    public int rate;
    public int channels;
}

