/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.util.pathfinding;

import org.newdawn.slick.util.pathfinding.Mover;
import org.newdawn.slick.util.pathfinding.Path;

public interface PathFinder {
    public Path findPath(Mover var1, int var2, int var3, int var4, int var5);
}

