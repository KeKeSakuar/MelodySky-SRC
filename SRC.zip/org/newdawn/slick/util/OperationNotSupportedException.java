/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.util;

public class OperationNotSupportedException
extends RuntimeException {
    public OperationNotSupportedException(String msg) {
        super(msg);
    }
}

