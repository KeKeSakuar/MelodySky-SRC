/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.util.xml;

import org.newdawn.slick.SlickException;

public class SlickXMLException
extends SlickException {
    public SlickXMLException(String message) {
        super(message);
    }

    public SlickXMLException(String message, Throwable e) {
        super(message, e);
    }
}

