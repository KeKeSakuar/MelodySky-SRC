/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.gui;

import org.newdawn.slick.gui.AbstractComponent;

public interface ComponentListener {
    public void componentActivated(AbstractComponent var1);
}

