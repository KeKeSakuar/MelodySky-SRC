/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.injection.throwables;

import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.throwables.InvalidInjectionException;
import org.spongepowered.asm.mixin.refmap.IReferenceMapperContext;

public class InvalidSliceException
extends InvalidInjectionException {
    private static final long serialVersionUID = 1L;

    public InvalidSliceException(IReferenceMapperContext context, String message) {
        super(context, message);
    }

    public InvalidSliceException(InjectionInfo info, String message) {
        super(info, message);
    }

    public InvalidSliceException(IReferenceMapperContext context, Throwable cause) {
        super(context, cause);
    }

    public InvalidSliceException(InjectionInfo info, Throwable cause) {
        super(info, cause);
    }

    public InvalidSliceException(IReferenceMapperContext context, String message, Throwable cause) {
        super(context, message, cause);
    }

    public InvalidSliceException(InjectionInfo info, String message, Throwable cause) {
        super(info, message, cause);
    }
}

