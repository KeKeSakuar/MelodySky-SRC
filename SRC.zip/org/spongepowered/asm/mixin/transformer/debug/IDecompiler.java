/*
 * Decompiled with CFR 0.152.
 */
package org.spongepowered.asm.mixin.transformer.debug;

import java.io.File;

public interface IDecompiler {
    public void decompile(File var1);
}

