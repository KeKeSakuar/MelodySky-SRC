/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick;

import org.newdawn.slick.Music;

public interface MusicListener {
    public void musicEnded(Music var1);

    public void musicSwapped(Music var1, Music var2);
}

