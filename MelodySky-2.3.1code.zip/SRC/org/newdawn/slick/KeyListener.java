/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick;

import org.newdawn.slick.ControlledInputReciever;

public interface KeyListener
extends ControlledInputReciever {
    public void keyPressed(int var1, char var2);

    public void keyReleased(int var1, char var2);
}

