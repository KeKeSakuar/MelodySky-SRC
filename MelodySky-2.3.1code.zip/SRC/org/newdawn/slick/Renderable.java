/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick;

public interface Renderable {
    public void draw(float var1, float var2);
}

