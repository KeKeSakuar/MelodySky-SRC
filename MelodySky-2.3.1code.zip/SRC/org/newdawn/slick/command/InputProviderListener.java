/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.command;

import org.newdawn.slick.command.Command;

public interface InputProviderListener {
    public void controlPressed(Command var1);

    public void controlReleased(Command var1);
}

