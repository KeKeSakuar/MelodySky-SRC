/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick;

import org.newdawn.slick.ControllerListener;
import org.newdawn.slick.KeyListener;
import org.newdawn.slick.MouseListener;

public interface InputListener
extends MouseListener,
KeyListener,
ControllerListener {
}

