/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.particles;

import org.newdawn.slick.particles.ConfigurableEmitter;

public interface ConfigurableEmitterFactory {
    public ConfigurableEmitter createEmitter(String var1);
}

