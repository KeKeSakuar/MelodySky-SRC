/*
 * Decompiled with CFR 0.152.
 */
package org.newdawn.slick.util.pathfinding;

public interface Mover {
}

