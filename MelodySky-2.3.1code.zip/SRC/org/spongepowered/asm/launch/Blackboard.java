/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.launchwrapper.Launch
 */
package org.spongepowered.asm.launch;

import net.minecraft.launchwrapper.Launch;

public final class Blackboard {
    private Blackboard() {
    }

    public static <T> T get(String key) {
        return (T)Launch.blackboard.get(key);
    }

    public static void put(String key, Object value) {
        Launch.blackboard.put(key, value);
    }

    public static <T> T get(String key, T defaultValue) {
        Object value = Launch.blackboard.get(key);
        return (T)(value != null ? value : defaultValue);
    }

    public static String getString(String key, String defaultValue) {
        Object value = Launch.blackboard.get(key);
        return value != null ? value.toString() : defaultValue;
    }

    public static final class Keys {
        public static final String TWEAKCLASSES = "TweakClasses";
        public static final String TWEAKS = "Tweaks";
        public static final String INIT = "mixin.initialised";
        public static final String AGENTS = "mixin.agents";
        public static final String CONFIGS = "mixin.configs";
        public static final String TRANSFORMER = "mixin.transformer";
        public static final String FML_LOAD_CORE_MOD = "mixin.launch.fml.loadcoremodmethod";
        public static final String FML_GET_REPARSEABLE_COREMODS = "mixin.launch.fml.reparseablecoremodsmethod";
        public static final String FML_CORE_MOD_MANAGER = "mixin.launch.fml.coremodmanagerclass";
        public static final String FML_GET_IGNORED_MODS = "mixin.launch.fml.ignoredmodsmethod";

        private Keys() {
        }
    }
}

